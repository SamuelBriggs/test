package com.practice.practicteTest;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PracticteTestApplicationTests {

	@Test
	void contextLoads() {
	}

}
