package com.practice.practicteTest.dtos.responses;

public class TransferSuccessResponse {
}
