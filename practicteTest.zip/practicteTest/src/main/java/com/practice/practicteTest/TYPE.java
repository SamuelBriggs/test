package com.practice.practicteTest;

import jakarta.persistence.Entity;
import jakarta.persistence.Id;


public enum TYPE { RETAIL, BUSINESS;

}
